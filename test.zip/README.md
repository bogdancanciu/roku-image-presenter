# roku-image-presenter
In order to be able to deploy the application, do the following:
1. Compress the content of the current repo into a .zip archive
2. Go to your favorite web browser and surf to YOUR-ROKU-DEVICE IP Address (ex:192.168.xx.xx)
3. Click the upload button, go to the .zip archive created during the first step and select it
4. Hit the install button
5. Check the display your roku device is connected to in order to see the output of the current application.
